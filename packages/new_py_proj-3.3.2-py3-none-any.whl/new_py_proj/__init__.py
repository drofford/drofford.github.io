__version__ = "3.3.2"

import daiquiri
import logging as _logging
import os

log_level = _logging.DEBUG if os.getenv("DEBUG", "") == "Y" else _logging.INFO

daiquiri.setup(log_level)
logger = daiquiri.getLogger(__name__)
