import attr


@attr.s
class Options:
    blank_value = attr.ib(default="")
    separator = attr.ib(default="")
    remove_trailing_whitespace = attr.ib(default=False)
    inp_filenames = attr.ib(default=None)
    out_filename = attr.ib(default=None)
