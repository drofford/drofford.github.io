import argparse
import os
import os.path
import pathlib
import re
import sys
import texttable

from biglib import logger, __version__ as VERSION
from biglib.parser import parse


def do(args: dict) -> (bool, list):
    return True, None


def main():
    logger.info("We made it!")

    args = parse()
    logger.debug(f"command line arguments are: {args}")

    r, t = do(args)
    logger.debug(f"do() returned {r}")

    return 0 if r else 1


if __name__ == "__main__":
    main()
