import logging
import os
import re

from gao_normalize.normalize_name.logic import perform as gao_normalize


def perform(words, abbrevs):

    old_name = " ".join(words)
    if not os.path.exists(old_name):
        return False, [f"No such file or directory: \"{old_name}\""]

    r, new_name = gao_normalize(words, abbrevs)
    logging.debug(f"Old name = {old_name}")
    logging.debug(f"New name = {new_name}")

    if old_name == new_name:
        return True, [f'File name "{old_name}" is already gao_normalized']
    if os.path.exists(new_name):
        return False, [
            f"The gao_normalized name \"{new_name}\" is already used",
            f"File \"{old_name}\" was NOT renamed",
        ]


    os.rename(old_name, new_name)
    return True, [f'File name "{old_name}" gao_normalized to "{new_name}"']
