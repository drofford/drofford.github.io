import argparse
import logging
import os
import os.path
import re
import sys

from gao_normalize import logger, __version__ as VERSION, ABBREVS


def parse():
    VER = os.path.split(sys.argv[0])[1] + ", version " + VERSION

    parser = argparse.ArgumentParser(
        description="""
        gao_normalizes file names by converting spaces, slashes, etc
        to underscores.  Hyphens and underscore are reduced to the
        minimum necessary not to look weird. Periods are left unchanged."""
    )
    parser.add_argument("-v", "--version", action="version", version="%(prog)s, version " + VERSION)
    parser.add_argument(
        "-a",
        "--abbrevs",
        action="store_true",
        help="""
        if set, separated standard abbreviations such as A_P_I and I_D are reduced
        to what you'd expect: API and ID. You can use the -A option to show the
        current list of these abbreviations.
        """,
    )
    parser.add_argument(
        "-A",
        "--list-abbrevs",
        action="store_true",
        help="""
        displays the mapping of abbreviations. Program will exit with a code of 1
        and no normalizations will take place.
        """,
    )
    parser.add_argument(
        "words",
        metavar="ELEMENT",
        nargs="*",
        help="""
        element(s) of the File name.
        Note that the file name cannot contain any subdirectories, because the
        the path separators (typically "/" will also be gao_normalized.""",
    )

    args = parser.parse_args()
    logging.debug(args)

    if args.list_abbrevs:
        if args.words:
            parser.error("You cannot specify both -A and a file name.")
        t = tt.Texttable()
        t.add_row(["Mangled Abbreviation", "Normalized Abbreviation"])
        for a, b in ABBREVS.items():
            t.add_row([a, b])
        print(t.draw())
        exit(1)

    if not args.words:
        parser.error(
            "You must either specify -A or a file name with at least one word."
        )

    return args, ABBREVS

    # print(perform(args.words, args.abbrevs))
