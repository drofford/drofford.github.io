import argparse
import os
import os.path
import re
import sys

from pathlib import Path

from biglib import __version__ as VERSION, logger


def parse() -> dict:
    parser = argparse.ArgumentParser()

    parser.add_argument("-V", "--version", action="version", version="%(prog)s, version " + VERSION)

    parser.add_argument("-b", "--boolean", help="turn feature on")
    parser.add_argument("-o", "--output-file", metavar="FILENAME", help="name of output file")

    parser.add_argument("file1", metavar="INP-FILE-1", help="first input file (required)")
    parser.add_argument("file2", metavar="INP-FILE-2", nargs="?", help="second input file (optional)")

    args = vars(parser.parse_args())
    logger.info(f"{args=}")

    return args
