from gao_normalize import logger
from gao_normalize.normalize_name.cli import parse
from gao_normalize.normalize_name.logic import perform


def main():
    args, abbrevs = parse()
    r, t = perform(args.words, abbrevs)
    if r:
        print(t)
    else:
        for e in t:
            logger.error(e)

if __name__ == "__main__":
    main()
