import argparse
import os
import os.path
import pathlib
import re
import sys
import time

from jinja2 import Environment, PackageLoader, select_autoescape
from pathlib import Path

from new_py_proj import __version__ as VERSION, logger
from new_py_proj.parser import parse
from new_py_proj.files.any_file import AnyFile
from new_py_proj.files.bumpversion_cfg import BumpVersionCfg
from new_py_proj.files.gitignore_file import GitIgnoreFile
from new_py_proj.files.init_py_file import InitPyFile
from new_py_proj.files.makefile import Makefile
from new_py_proj.files.parser_py_file import ParserPyFile
from new_py_proj.files.pyproject_toml_file import PyProjectTomlFile
from new_py_proj.files.package_init_py_file import PackageInitPyFile
from new_py_proj.files.package_main_py_file import PackageMainPyFile
from new_py_proj.tools.writer import Writer


def generated_directory():
    return "generated"


def do(args: dict) -> bool:
    assert isinstance(args, dict)

    logger.debug(f"current dir = {pathlib.Path.cwd()}")

    env = Environment(
        loader=PackageLoader("new_py_proj", "templates"),
        autoescape=select_autoescape(["html", "xml"]),
    )

    ctx = {
        "tab": "\t",
        "program_name": args["program_name"],
        "project_name": args["project_name"],
        "project_version": args["project_version"],
        "bumpfile_version": args["bumpfile_version"],
        "author_name": args["author_name"] or "author",
        "author_email": args["author_email"] or "author@email.com",
    }

    outputters = list()
    outputters.append(BumpVersionCfg())
    outputters.append(GitIgnoreFile())
    outputters.append(Makefile())
    outputters.append(PyProjectTomlFile(env, ctx))
    outputters.append(PackageInitPyFile(env, ctx))
    outputters.append(PackageMainPyFile(env, ctx))
    outputters.append(ParserPyFile(env, ctx))
    outputters.append(InitPyFile(env, ctx, "model"))
    outputters.append(InitPyFile(env, ctx, "tools"))
    outputters.append(AnyFile(env, ctx, "test", "test_dummy.py"))

    gen_dir = (
        args["generated_directory"]
        if args["generated_directory"]
        else generated_directory
    )
    writer = Writer(env, gen_dir)

    writer.write_all(ctx, outputters)


def main():
    args = parse(sys.argv[1:])
    return 1 if do(args) else 0


if __name__ == "__main__":
    main()
