import argparse
import os
import os.path
import re
import sys

from pathlib import Path

from join_files import __version__ as VERSION, logger
from join_files.model.options import Options


def parse() -> [bool, Options]:
    options = Options()
    parser = argparse.ArgumentParser(
        description="""Combines multiple input text files into one output test file."""
    )

    parser.add_argument(
        "-V", "--version", action="version", version="%(prog)s, version " + VERSION
    )

    parser.add_argument(
        "-b",
        "--blank-value",
        metavar="STR",
        default="",
        help="""
        define the string to be used for a blank file line when building a composite output line.
        The default is a zero length string""",
    )
    parser.add_argument(
        "-s",
        "--separator",
        metavar="STR",
        default="",
        help="""
        define the string placed between file segments when building a composite output line.
        Popular values are "|", ",", and " ". The default is a zero length string""",
    )
    parser.add_argument(
        "-o",
        "--out-filename",
        metavar="FILE",
        help="""
        name of the output file. If omitted, data is written to the standard output""",
    )
    parser.add_argument(
        "-t",
        "--trailing-whitespace",
        action="store_true",
        help="""
        trailing whitespace is not removed from lines read from the files. However,
        specifying the -t option will cause trailing whitespace to be removed.
        Newlines are always removed
        """,
    )

    parser.add_argument(
        "inp_filenames",
        metavar="TEXT-FILE",
        nargs="+",
        help="""input text file(s) to be processed""",
    )

    args = parser.parse_args()

    logger.debug(f"original args = {args}")

    return True, Options(
        blank_value=args.blank_value,
        separator=args.separator,
        remove_trailing_whitespace=args.trailing_whitespace,
        inp_filenames=args.inp_filenames,
        out_filename=args.out_filename,
    )
