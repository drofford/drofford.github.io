__version__ = "2.1.0"

import daiquiri
import logging as _logging
import os

log_level = _logging.DEBUG if os.getenv("DEBUG", "") == "Y" else _logging.INFO

daiquiri.setup(log_level)
logger = daiquiri.getLogger("normalize")

ABBREVS = {
    "A_P_I": "API",
    "I_D": "ID",
    "S_S_N": "SSN",
    "U_U_I_D": "UUID",
}
