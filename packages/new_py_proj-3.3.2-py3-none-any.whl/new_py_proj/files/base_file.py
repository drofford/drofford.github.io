from abc import ABCMeta, abstractmethod
from pathlib import Path
from jinja2 import Environment, PackageLoader, select_autoescape

from new_py_proj import logger


class BaseFile(metaclass=ABCMeta):
    def __init__(self):
        pass

    @abstractmethod
    def template_name(self):
        ...

    @abstractmethod
    def output_directory(self):
        ...

    @abstractmethod
    def output_file_name(self):
        ...

    def update_context(self, context):
        return context
