import argparse
import os
import os.path
import pathlib
import re
import sys
import texttable

from biglib.utils.text_utils import pluralize

from join_files import logger, __version__ as VERSION
from join_files.parser import parse
from join_files.worker import work


def main():
    errs = list()

    r, t = parse()
    if not r:
        errs.extend(t)

    else:
        r, t = work(t)
        if not r:
            errs.extend(t)

    if len(errs):
        logger.error(
            pluralize(
                "There {verb} {count} error{noun}",
                verbs=("are", "is"),
                nouns=("s", ""),
                count=len(t),
            )
        )
        for e in errs:
            logger.error(f"    * {e}")
        return 1

    return 0


if __name__ == "__main__":
    main()
