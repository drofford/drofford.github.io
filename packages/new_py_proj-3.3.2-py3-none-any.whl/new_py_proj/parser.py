import argparse
import os
import os.path
import re
import sys

from pathlib import Path

from new_py_proj import __version__ as VERSION, logger


def parse(argv) -> dict:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-V", "--version", action="version", version="%(prog)s, version " + VERSION
    )

    parser.add_argument(
        "-d",
        "--generated-directory",
        metavar="DIR",
        default=".",
        help="""
        specifies the directory into which the project should be generated. Note that the project
        directory will be created within this directory. If not specified, it defaults to the
        current directory
        """,
    )

    parser.add_argument("-a", "--author-name", metavar="NAME", help="author's name")
    parser.add_argument(
        "-e", "--author-email", metavar="EMAIL", help="author's email address"
    )

    parser.add_argument(
        "project_name", metavar="PROJECT-NAME", help="""the project name"""
    )
    parser.add_argument(
        "project_version",
        metavar="PROJECT-VERSION",
        nargs="?",
        default="1.0.0",
        help="""the project version. If not specified, it will default to 1.0.0 """,
    )

    args = vars(parser.parse_args(argv))

    h = re.findall("(.+)?-([0-9a-zA-Z.]+)$", args["project_name"])
    logger.debug(f"{h=}")
    if len(h) > 0 and len(h[-1]) == 2:
        args["project_name"] = "-".join(h[-1][0:-1])
        args["project_version"] = h[-1][-1]

    args["project_name"] = args["project_name"].replace("-", "_").lower()
    args["program_name"] = args["project_name"].replace("_", "-")

    h = re.findall(r"^(\d+)(\.(\d+))?(\.(\d+))?(\.([A-Za-z]+))?",  args["project_version"])
    logger.debug(f"{h=}")
    if len(h) > 0 and len(h[-1]) == 7:
        version_parts = []
        version_parts.append(h[-1][0] if h[-1][0] else "1")
        version_parts.append(h[-1][2] if h[-1][2] else "0")
        version_parts.append(h[-1][4] if h[-1][4] else "0")
        # version_parts.append(h[-1][6] if h[-1][6] else "1")
        bumpfile_version = ".".join(version_parts)
        logger.debug(f"    major            = {h[-1][0]}")
        logger.debug(f"    minor            = {h[-1][2]}")
        logger.debug(f"    patch            = {h[-1][4]}")
        logger.debug(f"    dev              = {h[-1][6]}")
        logger.debug(f"    bumpfile_version = {bumpfile_version}")
        args["bumpfile_version"] = bumpfile_version
    else:
        args["bumpfile_version"] = args["project_version"]

    logger.debug(f"{args=}")

    return args
