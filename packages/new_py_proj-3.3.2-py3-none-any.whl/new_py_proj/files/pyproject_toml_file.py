from pathlib import Path

import re
import sys
from jinja2 import Environment, PackageLoader, select_autoescape
from new_py_proj.files.base_file import BaseFile

from new_py_proj import logger


class PyProjectTomlFile(BaseFile):
    def __init__(self, env: Environment, ctx: dict):
        super().__init__()
        self.env = env
        self.ctx = ctx

    def template_name(self) -> str:
        return "pyproject_toml.jinja"

    def output_directory(self) -> str:
        return "."

    def output_file_name(self) -> str:
        return "pyproject.toml"
