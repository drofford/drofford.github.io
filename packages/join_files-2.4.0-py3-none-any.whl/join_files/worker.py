import json
import os
import os.path
import re
import sys

from functools import reduce

from biglib.utils.text_utils import pluralize

from join_files import logger
from join_files.model.input_file import InputFile
from join_files.model.options import Options


def work(options: Options) -> bool:
    logger.debug(f"work: {options=}")

    logger.debug(
        pluralize(
            "Opening {count} input file{noun}",
            count=len(options.inp_filenames),
            nouns=("s", ""),
        )
    )

    files = list()
    for inp_filename in options.inp_filenames:
        files.append(
            InputFile(
                inp_filename=inp_filename,
                post_eof_val=options.blank_value,
                remove_trailing_whitespace=options.remove_trailing_whitespace,
            )
        )

    logger.debug(
        pluralize(
            "We have opened {count} input file{noun}",
            count=len(options.inp_filenames),
            nouns=("s", ""),
        )
    )

    if options.out_filename is None or options.out_filename == "-":
        out_file = sys.stdout
        needs_close = False
    else:
        out_file = open(options.out_filename, "wt")
        needs_close = True

    while any([file.has_more() for file in files]):
        logger.debug("Loop: Some files are still open")
        combo_line = None
        for file in files:
            r, t = file.read_line()
            if not r:
                t = options.blank_value
            if combo_line is None:
                combo_line = t
            else:
                combo_line = combo_line + options.separator + t
        out_file.write(combo_line + "\n")
        out_file.flush()

    if needs_close:
        out_file.close()

    return True, None
