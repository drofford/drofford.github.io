import attr
import os
import os.path

from biglib.utils.text_utils import pluralize

from join_files import logger


@attr.s
class InputFile:
    inp_filename = attr.ib()
    post_eof_val = attr.ib(default="")
    remove_trailing_whitespace = attr.ib(default=False)

    def __attrs_post_init__(self):
        self.lines = [
            (x.rstrip() if self.remove_trailing_whitespace else x[:-1])
            for x in open(self.inp_filename, "rt")
        ]
        self.next_line_num = 0
        logger.debug(
            pluralize(
                f'InputFile#ctor: file="{self.inp_filename}":'
                + " cached {count} line{noun}",
                count=len(self.lines),
                nouns=("s", ""),
            )
        )

    def has_more(self):
        flag = self.next_line_num < len(self.lines)
        logger.debug(
            f'InputFile#has_more: file="{self.inp_filename}": {self.next_line_num=}, {(len(self.lines)-1)=}, {flag=}'
        )
        return flag

    def read_line(self):
        if not self.has_more():
            return False, None
        logger.debug(
            f'InputFile#read_line: file="{self.inp_filename}": before accessing cache call'
        )
        line = self.lines[self.next_line_num]
        logger.debug(
            f'InputFile#read_line: file="{self.inp_filename}": retrieved: {line=}'
        )
        self.next_line_num += 1
        logger.debug(
            f'InputFile#read_line: file="{self.inp_filename}": bumped next_line_num to: {self.next_line_num}'
        )
        return True, line
