from pathlib import Path

import re
import sys
from jinja2 import Environment, PackageLoader, select_autoescape
from new_py_proj.files.base_file import BaseFile

from new_py_proj import logger


class AnyFile(BaseFile):
    def __init__(self, env: Environment, ctx: dict, subdir: str = None, file_name=None):
        super().__init__()
        self.env = env
        self.ctx = ctx
        self.subdir = subdir
        self.file_name = file_name if file_name else "any_file.py"

    def template_name(self) -> str:
        return "any_file.jinja"

    def output_directory(self) -> str:
        return Path(".") / self.subdir

    def output_file_name(self) -> str:
        return self.file_name
