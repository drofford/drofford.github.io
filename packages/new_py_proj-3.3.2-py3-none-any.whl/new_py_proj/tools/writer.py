import argparse
import os
import os.path
import pathlib
import re
import sys
import time

from jinja2 import Environment, PackageLoader, select_autoescape
from pathlib import Path

from new_py_proj import logger
from new_py_proj.files.base_file import BaseFile


class Writer:
    def __init__(self, env: Environment, output_directory=None):
        self.env = env
        self.output_directory = output_directory if output_directory else "."

    def write_all(self, base_context: dict, outputters: list):
        assert isinstance(base_context, dict)

        logger.debug(f"writer: {type(outputters)=}, {len(outputters)=}")
        assert isinstance(outputters, list)

        if len(outputters) > 0:
            logger.debug(f"writer: {type(outputters[0])=}")
            assert isinstance(outputters[0], BaseFile)

        for i, outputter in enumerate(outputters, start=1):
            logger.debug(f"writer: outputting file {i:2} of {len(outputters):2}:")
            fn = self.write_one(base_context, outputter)

            print(f"Created file {i:2} of {len(outputters):2}: {fn}")

    def write_one(self, base_context: dict, outputter: BaseFile) -> None:
        assert isinstance(base_context, dict)

        logger.debug(f"write_one: {type(outputter)=}")
        assert isinstance(outputter, BaseFile)

        od = pathlib.Path(self.output_directory)
        od = od / (base_context["project_name"] + "-" + base_context["project_version"])
        od = od / outputter.output_directory()
        of = outputter.output_file_name()
        op = Path(od) / of
        tn = outputter.template_name()
        cx = dict(base_context)  # if base_context     else dict()

        logger.debug(f"write_one: od={str(od)}")
        logger.debug(f"write_one: {of=}")
        logger.debug(f"write_one: op={str(op)}")
        logger.debug(f"write_one: {tn=}")
        logger.debug(f"write_one: {cx=}")

        outputter.update_context(cx)
        tm = self.env.get_template(tn)
        ft = tm.render(cx)

        od.mkdir(parents=True, exist_ok=True)
        with open(op, "wt") as out:
            if len(ft):
                out.write(ft)
                out.write("\n")
            logger.debug(f"created file {out.name}")
            return out.name
