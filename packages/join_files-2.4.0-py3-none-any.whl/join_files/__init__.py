__version__ = "2.4.0"

import daiquiri
import logging as _logging
import os

log_level = _logging.DEBUG if os.getenv("DEBUG", "") == "Y" else _logging.INFO

daiquiri.setup(log_level)
logger = daiquiri.getLogger("join-files")
