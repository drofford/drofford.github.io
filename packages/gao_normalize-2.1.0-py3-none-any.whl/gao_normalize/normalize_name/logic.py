import logging
import re

ABBREVS = {"A_P_I": "API", "I_D": "ID", "U_U_I_D": "UUID"}


def perform(words, abbrevs):
    t = "_".join(words)
    logging.debug("original: full name = {}".format(t))

    t = re.sub("[^-_A-Za-z0-9.]+", "_", t)
    logging.debug("transformation: t   = {}".format(t))

    t = re.sub("-+", "-", t)
    t = re.sub("_+", "_", t)
    t = re.sub("_+-+", "-", t)
    t = re.sub("-+_+", "-", t)
    t = re.sub("-+", "-", t)
    t = re.sub("_+", "_", t)
    t = re.sub("^[-_]+", "", t)
    t = re.sub("[-_]$", "", t)
    t = re.sub("[-_]+(\\.[^.]+)$", "\\1", t)
    logging.debug("transformation: t   = {}".format(t))

    if abbrevs:
        for a, b in ABBREVS.items():
            t = re.sub(a, b, t)
        logging.debug("transformation: t   = {}".format(t))

    return True, t
